# Final Deliverables Checklist

- [ ] Database ER diagram PDF (in SRS package)
- [ ] Test Plan and Test Cases Excel
- [ ] Public solution HTTPS URL
- [ ] Source code package (tagged)
- [ ] Case Study Report PDF
- [ ] Presentation PPT
- [ ] Presentation recording MP4
- [ ] Walkthrough Video V1.2 MP4
- [ ] Exit Survey submission proof

## Advisor Review Packet (May 2)

- [ ] FR-01 to FR-94 matrix draft complete
- [ ] Service test summary (methods covered)
- [ ] Endpoint smoke/integration summary
- [ ] Defect list with remediation ETA
- [ ] Deployment URL and status
