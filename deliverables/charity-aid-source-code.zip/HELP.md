# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/3.5.12/maven-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/3.5.12/maven-plugin/build-image.html)
* [Spring Web](https://docs.spring.io/spring-boot/3.5.12/reference/web/servlet.html)
* [Spring Security](https://docs.spring.io/spring-boot/3.5.12/reference/web/spring-security.html)
* [Spring Data JPA](https://docs.spring.io/spring-boot/3.5.12/reference/data/sql.html#data.sql.jpa-and-spring-data)
* [Validation](https://docs.spring.io/spring-boot/3.5.12/reference/io/validation.html)
* [Spring Boot DevTools](https://docs.spring.io/spring-boot/3.5.12/reference/using/devtools.html)
* [Java Mail Sender](https://docs.spring.io/spring-boot/3.5.12/reference/io/email.html)
* [Spring Boot Actuator](https://docs.spring.io/spring-boot/3.5.12/reference/actuator/index.html)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)
* [Securing a Web Application](https://spring.io/guides/gs/securing-web/)
* [Spring Boot and OAuth2](https://spring.io/guides/tutorials/spring-boot-oauth2/)
* [Authenticating a User with LDAP](https://spring.io/guides/gs/authenticating-ldap/)
* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)
* [Accessing data with MySQL](https://spring.io/guides/gs/accessing-data-mysql/)
* [Validation](https://spring.io/guides/gs/validating-form-input/)
* [Building a RESTful Web Service with Spring Boot Actuator](https://spring.io/guides/gs/actuator-service/)

### Maven Parent overrides

Due to Maven's design, elements are inherited from the parent POM to the project POM.
While most of the inheritance is fine, it also inherits unwanted elements like `<license>` and `<developers>` from the parent.
To prevent this, the project POM contains empty overrides for these elements.
If you manually switch to a different parent and actually want the inheritance, you need to remove those overrides.

### Local Run Setup

To run this project on a new laptop using the VS Code Run button:

1. Copy `.env.local.example` to `.env.local`
2. Fill in the SMTP values in `.env.local`
3. Make sure MySQL is running and the `charity_aid_db` database exists
4. In VS Code Run and Debug, choose `Run Charity Aid`

Required values in `.env.local`:

* `BREVO_SMTP_USERNAME` = the Brevo SMTP login shown in Brevo SMTP settings
* `BREVO_SMTP_KEY` = the Brevo SMTP key
* `MAIL_FROM` = a verified sender email in Brevo
* `APP_BASE_URL` = `http://localhost:8080` for local development

Notes:

* Do not put real secrets in `application.properties`
* `.env.local` is ignored by git and stays local to each laptop
* The SMTP username is not your sender email unless Brevo explicitly shows it that way

